from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.shortcuts import reverse

class Book(models.Model):
	user = models.ForeignKey(User,on_delete = models.CASCADE,blank = True,null=True)
	title = models.CharField(verbose_name = 'タイトル',max_length = 200)
	author = models.CharField(verbose_name = '著者',max_length = 20)
	url = models.CharField(verbose_name = 'url',max_length = 200,null=True)
	published_date = models.DateTimeField(auto_now_add = True)
	def __str__(self):
		return self.title


