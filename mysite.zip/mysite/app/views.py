from django.shortcuts import render,redirect,get_object_or_404,HttpResponse,reverse
from django.urls import reverse_lazy
from django.http import HttpResponse
from django.conf import settings
from .models import Book
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from .forms import BookForm
from django.views.generic import ListView,DetailView,CreateView,DeleteView,UpdateView
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django_filters.views import FilterView
from django.db.models import Q
# Create your views here.



class ListView(LoginRequiredMixin,ListView):
	model = Book
	login_url = "login:login"
	template_name = "app/index.html"
	def get_queryset(self):
		q_word = self.request.GET.get('query')
 
		if q_word:
			object_list = Book.objects.filter(
                Q(title__icontains=q_word) | Q(author__icontains=q_word))
		else:
			object_list = Book.objects.all()
		return object_list

class CreateView(LoginRequiredMixin,CreateView):
	model = Book
	form_class= BookForm
	template_name = "app/create.html"
	def post(self, request, *args, **kwargs):
		form = self.get_form()
		if form.is_valid():
			list = form.save(commit=False)
			list.user_id = request.user.id
			list.save()
			form.save_m2m()
			return redirect('app:index')
		else:
			return redirect('app:index')
class DeleteView(DeleteView):
	model = Book
	template_name = "app/delete.html"
	success_url = reverse_lazy('app:index')
class EditView(UpdateView):
	model = Book
	template_name = "app/create.html"
	form_class = BookForm
	success_url = reverse_lazy('app:index')

