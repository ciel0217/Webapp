from django.urls import path

from . import views

app_name = "app"
urlpatterns = [
		path('',views.ListView.as_view(), name='index'),
		path('create/',views.CreateView.as_view(),name='create'),
		path('delete/<int:pk>/',views.DeleteView.as_view(),name ='delete'),
		path('edit/<int:pk>/',views.EditView.as_view(),name='edit'),
		
		]
