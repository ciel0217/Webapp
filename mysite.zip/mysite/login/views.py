from django.contrib.auth import login
from django.http import HttpResponseRedirect
from django.urls import reverse_lazy
from django.shortcuts import resolve_url,redirect,render
from django.views.generic.edit import CreateView
from .forms import SignUpForm,LoginForm
from django.contrib.auth import authenticate
from django.contrib.auth.views import LoginView,LogoutView
from django.contrib.auth.models import User
class SignUp(CreateView):
     def post(self, request, *args, **kwargs):
        form = SignUpForm(data=request.POST)
        if form.is_valid():
            form.save()
            #フォームから'username'を読み取る
            username = form.cleaned_data.get('username')
            #フォームから'password1'を読み取る
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('app:index')
        return render(request, 'app/signup.html', {'form': form,})

     def get(self, request, *args, **kwargs):
        form = SignUpForm(request.POST)
        return  render(request, 'app/signup.html', {'form': form,})

signup = SignUp.as_view()
class Login(LoginView):
    form_class = LoginForm
    template_name = 'app/login.html'

class Logout(LogoutView):
    tempalte_name = 'app/logout.html'
