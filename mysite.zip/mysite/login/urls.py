
from django.urls import path
from . import views
from .views import SignUp,Logout,Login

app_name = 'login'
urlpatterns = [
	path('',views.Login.as_view(),name='login'),
	path('logout/',views.Logout.as_view(),name='logout'),
	path('signup/',SignUp.as_view(),name='signup'),
]
